# egui_plot

[<img alt="github" src="https://img.shields.io/badge/github-emilk/egui_plot-8da0cb?logo=github" height="20">](https://github.com/emilk/egui_plot)
[![Latest version](https://img.shields.io/crates/v/egui_plot.svg)](https://crates.io/crates/egui_plot)
[![Documentation](https://docs.rs/egui_plot/badge.svg)](https://docs.rs/egui_plot)
[![unsafe forbidden](https://img.shields.io/badge/unsafe-forbidden-success.svg)](https://github.com/rust-secure-code/safety-dance/)
![MIT](https://img.shields.io/badge/license-MIT-blue.svg)
![Apache](https://img.shields.io/badge/license-Apache-blue.svg)
[![Discord](https://img.shields.io/discord/900275882684477440?label=egui%20discord)](https://discord.gg/JFcEma9bJq)

Immediate mode 2D plotting library for [`egui`](https://crates.io/crates/https://github.com/emilk/egui).

[![egui_plot_white](https://github.com/user-attachments/assets/b29acf5e-ccbf-4cb7-b03b-7e258fa5db16)](https://emilk.github.io/egui_plot/)

[Try the web demo gallery](https://emilk.github.io/egui_plot/).

## Testing

- Locally: `cargo run -p demo`
- Web: `(cd demo && trunk serve)`

## Plotting libraries in Rust

To view a list of plotting libraries in Rust, see [notes on Rust plotting ecosystem](https://github.com/emilk/egui_plot/blob/main/ECOSYSTEM.md).

## Contributing

Please see [CONTRIBUTING.md](https://github.com/emilk/egui_plot/blob/main/CONTRIBUTING.md) and [WELCOME_CONTRIBUTIONS.md](https://github.com/emilk/egui_plot/blob/main/WELCOME_CONTRIBUTIONS.md)

## History

This crate was originally hosted at <https://github.com/emilk/egui> but was extracted into its own repository on 2024-07-15.
